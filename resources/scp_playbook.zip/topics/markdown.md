# Authoring

Any text-based editor is suitable. To view a preview of the content you could use OxygenXML, VS Code, NotePad++, etc.

**Note:** Both NotePad++ and VS Code require some configuration to enable markdown preview.

## NotePad++

Can be installed via Baxter software portal.

A Markdown preview pane can be installed:
- Plugins > Plugins Admin
- Search “Markdown”
- ☑ Markdown Panel, or ☑ MarkdownViewer 

## VS Code

Install VS Code. See: [XML Editors](prerequisites_xml-editors.dita)

A Markdown preview pane can be installed:
- Press `Ctrl + P` to access the 'Quick Open' menu
- Type `ext install` to manage extensions
- Search for: 'Markdown All in One' 
- Install extension
- Press `Ctrl + Shift + V` to toggle preview

## Converting Markdown-to-DITA via OxygenXML

1. Help > Install new add-ons
2. Show add-ons from: “-- All Available Sites –"
3. ☑ Batch Converter
4. Install
5. Tools > Batch Converter > Markdown to DITA
6. ‘Add files’ then ‘Convert’

## DITA-OT conversion

1. Download & install [DITA Open Toolkit](https://www.dita-ot.org/)
2. Building content: [Building output using the dita command](https://www.dita-ot.org/3.6/topics/build-using-dita-command.html)
3. Converting [MD-to-DITA](https://www.dita-ot.org/3.6.1/topics/markdown-input.html)
[DITA-to-MD](https://www.dita-ot.org/3.6.1/topics/dita2markdown.html)