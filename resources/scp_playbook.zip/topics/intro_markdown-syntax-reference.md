---
author: Owen Rowe
publisher: Baxter
audience: Intermediate
category: Reference
keyword:
  - markdown
  - DITA
  - lwDITA
workflow: review
---

# Markdown DITA syntax reference {#intro_markdown-syntax}

**Note:** Markdown DITA files must be UTF-8 encoded. 

## Titles and document structure

Each header level will generate a topic and associated title:

``` markdown
# Topic title
## Nested topic title
```

## Inline 

| Markdown            | Result            |
| ------------------- | ----------------- |
| ` **bold** `        | **bold**          |
| `*italic*`          | *italic*          |
| \`code\`            | `code`            |
| `~~strikethrough~~` | ~~strikethrough~~ |


## Lists 

* one
* two
   * three
   * four
    
1. one
1. two
1. three


## Tables 

Tables use [MultiMarkdown](http://fletcherpenney.net/multimarkdown/) table extension format:

``` markdown
| Left aligned header | Center aligned Header | Right aligned header |
| :------------------ | :-------------------: | -------------------: |
| Content             | *Long Cell*           |                      |
| Content             | **Cell**              | Cell                 |
```

| Left aligned header | Center aligned Header | Right aligned header |
| :------------------ | :-------------------: | -------------------: |
| Content             | *Long Cell*           |                      |
| Content             | **Cell**              | Cell                 |

Table cells may only contain inline content and column spans; block content and row spans are not supported by Markdown DITA.

## Links

The format of local link targets is detected based on file extension. The following extensions are treated as DITA files:

``` markdown
| Extension | Format   |
| :-------: | :------: |
| .dita     | dita     |
|.xml       | dita     |
| .md       | markdown |
| .markdown | markdown |
```

| Extension | Format   |
| :-------: | :------: |
| .dita     | dita     |
|.xml       | dita     |
| .md       | markdown |
| .markdown | markdown |

``` markdown
[Markdown](test.md)
[DITA](test.dita)
[HTML](test.html)
[External](http://www.example.com/test.html)
```
[Markdown](test.md)
[DITA](test.dita)
[HTML](test.html)
[External](http://www.example.com/test.html)

## Images

Images used in inline content will result in inline placement. If a block level image contains a title, it will be treated as an image wrapped in figure:

``` markdown
An inline ![alt text](../images/test.svg).

![alt text](../images/test.svg)

![alt text](../images/test.svg "Markdown image")
```

An inline ![alt text](../images/test.svg).

![alt text](../images/test.svg)

![alt text](../images/test.svg "Markdown image")